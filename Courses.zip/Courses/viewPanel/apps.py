from django.apps import AppConfig


class ViewpanelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'viewPanel'
